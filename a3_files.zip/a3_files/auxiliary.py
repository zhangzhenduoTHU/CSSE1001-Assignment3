from mob import Mob
import random
import cmath
import tkinter as tk
from item import Item, SimpleItem, HandItem, BlockItem, MATERIAL_TOOL_TYPES, TOOL_DURABILITIES
from block import Block, ResourceBlock

# Implement of FoodItem
class FoodItem(Item):
    def __init__(self, id_, strength: float):
        super().__init__(id_)
        self.strength = strength

    def get_strength(self):
        return self.strength

    def place(self):
        return [('effect', ('food',2))]

    def can_attack(self):
        return False

    def get_durability(self):
        pass

    def get_max_durability(self):
        pass

    def attack(self, successful):
        pass

# Implement of ToolItem
class ToolItem(Item):
    def __init__(self, item_id: str, tool_type: str, durability: float):
        super().__init__(item_id, 1)
        self.tool_type = tool_type
        self.durability = durability

    def get_type(self):
        return self.tool_type

    def get_durability(self):
        return self.durability

    def can_attack(self):
        if self.get_durability() > 0:
            return True
        else:
            return False

    def attack(self, successful):
        if not successful:
            self.durability -= 1

    def get_max_durability(self):
        string = self.get_id()
        material = string.split("_")[0]
        return TOOL_DURABILITIES[material]


# Implement of Sheep, Sheep is a subclass of Mob
class Sheep(Mob):
    def step(self, time_delta, game_data):
        """Advance this sheep by one time step

        See PhysicalThing.step for parameters & return"""
        # Every 20 steps; could track time_delta instead to be more precise
        if self._steps % 10 == 0:
            # a random point on a movement circle (radius=tempo), scaled by the percentage
            # of health remaining
            health_percentage = self._health / self._max_health
            z = cmath.rect(self._tempo * health_percentage, random.uniform(0, 2 * cmath.pi))

            # stretch that random point onto an ellipse that is wider on the x-axis
            dx, dy = z.real * 1.61803, 0  # the speed component on the y-axis is 0

            x, y = self.get_velocity()
            y = 0
            velocity = x + dx, y + dy

            self.set_velocity(velocity)

        super().step(time_delta, game_data)

    def use(self):
        return ('sheep', 'wool')

    def get_drops(self):

        return [('item', ("wool",))]

# Implement of Bee class, Bee is a subclass of Mob
class Bee(Mob):
    """A friendly bird, nonchalant with a dash of cheerfulness"""

    def step(self, time_delta, game_data):
        """Advance this bee by one time step

        See PhysicalThing.step for parameters & return"""
        # Every 20 steps; could track time_delta instead to be more precise
        if self._steps % 15 == 0:
            # a random point on a movement circle (radius=tempo), scaled by the percentage
            # of health remaining
            health_percentage = self._health / self._max_health
            z = cmath.rect(self._tempo * health_percentage, random.uniform(0, 2 * cmath.pi))

            # stretch that random point onto an ellipse that is wider on the x-axis
            dx, dy = z.real * 1.61803, z.imag

            x, y = self.get_velocity()
            velocity = x + dx, y + dy - 150

            self.set_velocity(velocity)

        super().step(time_delta, game_data)

    def use(self):
        pass


# Implement of CraftingTableBlock class, CraftingTableBlock is a subclass of ResourceBlock
class CraftingTableBlock(ResourceBlock):
    def __init__(self):
        super().__init__(block_id = "crafting_table", break_table = {"hand": (7.5, True)})
        self._id = "crafting_table"

    def get_max_stack_size(self):
        return 1

    def can_attack(self):
        return False

    def get_max_stack_size(self):
        return 1

    def is_stackable(self) -> bool:
        return True

    def get_attack_range(self) -> float:
        """(float) Returns the basic range at which this item's attack can reach, in block spans"""
        return 1

    def get_durability(self):
        """(float) Returns the item's durability (effectively its health). For items that cannot
        attack, this value is irrelevant"""
        return 1

    def get_max_durability(self):
        """(float) Returns the item's maximum durability"""
        return 1

    def use(self):
        return ('crafting', 'crafting_table')

    def place(self):
        """Places the item into the world in its block form

        Return:
            [tuple<str, tuple<str, ...>>]:
                    A list of EffectIDs resulting from placing this item. Each EffectID is a pair
                    of (effect_type, effect_sub_id) pair, where:
                      - effect_type is the type of the effect ('item', 'block', etc.)
                      - effect_sub_id is the unique identifier for an effect of a particular type
        """
        return [('block', (self._id,))]

    def get_drops(luck = 0, correct_item_used = True):
        return [('item', ('crafting_table',))]

# Implement of Furnace class, Furnace is a subclass of ResourceBlock class
class Furnace(ResourceBlock):
    def __init__(self):
        super().__init__(block_id = "furnace", break_table = {"wood_pickaxe": (1.15, True),
                                                              "stone_pickaxe": (0.6, True), "iron_pickaxe": (0.4, True),})
        self._id = "furnace"

    def get_max_stack_size(self):
        return 1

    def can_attack(self):
        return False

    def get_max_stack_size(self):
        return 1

    def is_stackable(self) -> bool:
        return True

    def get_attack_range(self) -> float:
        """(float) Returns the basic range at which this item's attack can reach, in block spans"""
        return 1

    def get_durability(self):
        """(float) Returns the item's durability (effectively its health). For items that cannot
        attack, this value is irrelevant"""
        return 1

    def get_max_durability(self):
        """(float) Returns the item's maximum durability"""
        return 1

    def use(self):
        return ('furnace', 'furnace_table')

    def place(self):
        """Places the item into the world in its block form

        Return:
            [tuple<str, tuple<str, ...>>]:
                    A list of EffectIDs resulting from placing this item. Each EffectID is a pair
                    of (effect_type, effect_sub_id) pair, where:
                      - effect_type is the type of the effect ('item', 'block', etc.)
                      - effect_sub_id is the unique identifier for an effect of a particular type
        """
        return [('block', (self._id,))]

    def get_drops(luck = 0, correct_item_used = True):
        return [('item', ('furnace',))]

# Implement of HiveBlock, it is a subclass of Block
class HiveBlock(Block):
    """Swaying in the breeze, perhaps it hides a tasty surprise"""
    def __init__(self, _id):
        self._id = _id
        self._break_table = {
            "hand": (.1, True),
            "shears": (.4, True),
            "sword": (.2, False)
        }
    def use(self):
        return ('hive','hive')

    def can_use(self):
        """(bool) Returns False, since LeafBlocks cannot be used"""
        return False

    def get_drops(self):
        return ('item',(None,))